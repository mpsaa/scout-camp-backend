
CREATE TABLE campsites (
  id SERIAL PRIMARY KEY,
  name TEXT UNIQUE,
  region TEXT
);

CREATE TABLE campsite_weeks (
  id SERIAL PRIMARY KEY,
  campsite_id INT REFERENCES campsites(id),
  week_id INT,
  active BOOLEAN DEFAULT true,
  youth_count INT,
  adult_count INT,
  total_count INT
);

CREATE TABLE staff (
  id SERIAL PRIMARY KEY,
  name TEXT,
  assigned_region_id INT,
  assigned_area_id INT
);

CREATE TABLE activities (
  id SERIAL PRIMARY KEY,
  name TEXT,
  area_id INT,
  capacity INT,
  allow_split BOOLEAN DEFAULT false
);

CREATE TABLE preferences (
  id SERIAL PRIMARY KEY,
  campsite_id INT,
  activity_id INT,
  week_id INT,
  rank INT
);

CREATE TABLE schedules (
  id SERIAL PRIMARY KEY,
  campsite_id INT,
  activity_id INT,
  area_id INT,
  staff_id INT,
  day_of_week TEXT,
  time_slot TEXT,
  week_id INT,
  split_group BOOLEAN,
  overridden BOOLEAN
);

CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  username TEXT UNIQUE,
  password TEXT
);
